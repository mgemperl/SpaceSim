#pragma once

#include "AIState.h"

namespace SpaceSimNS
{
	/*template <class entity_type>
	LRESULT AIState<entity_type>::HandleUserInput(UINT message, WPARAM wParam, LPARAM lParam)
	{
		return S_OK;
	}*/

}